<?php

$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "servicio_social";

$pdo= new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $control = $_POST['control'];
    $dias = $_POST['dias'];
    $horas = $_POST['horas'];

foreach($dias as $dia){
    foreach($horas as $hora){
    $stmntselect = $pdo->prepare("SELECT * FROM horario_alumnos WHERE nocontrol = :nocontrol and dias = :dias AND hora = :horas");
    $stmntselect->bindParam(':nocontrol', $control);
    $stmntselect->bindParam(':dias', $dia);
    $stmntselect->bindParam(':horas', $hora);
    $success = $stmntselect->execute();

    if($success){
        $horarioregistrado = $stmntselect->fetchAll(PDO::FETCH_ASSOC);
        if(!empty($horarioregistrado)){
            $message = "El horario ya existe";
            header("Location: ../views/registro_horarios.php?message=$message".urlencode($message));
            exit();
        }else{

            $stmtinsert = $pdo->prepare("INSERT INTO horario_alumnos (nocontrol, dias, hora) VALUES (:control, :dias, :hora)");



                    $stmtinsert->bindParam(':control', $control);
                    $stmtinsert->bindParam(':dias', $dia);
                    $stmtinsert->bindParam(':hora', $hora);
                    $successinsert = $stmtinsert->execute();

                    if($successinsert){
                        echo "Horario registrado exitosamente";
                    } else {
                        echo "Error al registrar el horario";
                    }
                    }
                    }
            }
        }
}
