<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Horarios</title>
</head>
<body>
    <script src = "js/script.js"></script>
    <form action="../forms/registro_horario.php" method="post">
    <section>
        <label for="control"></label>
        <input type="text" id = "control" name = "control" value = '<?= $_GET['nocontrol']?>' >
        <input type="hidden" id = "nombre" name = "nombre"  value = '<?= $_GET['nombre']?>' >
    </section>
    <h2>Horarios</h2>
    <section>
        <h4>Dias</h4>

        <input id="dias[]" name="dias[]" value="Lunes" type="checkbox">
        <label for="dias[]"> Lunes </label>
        <br>

        <input id="dias[]" name="dias[]" value="Martes" type="checkbox">
        <label for="dias[]"> Martes</label>
        <br>

        <input id="dias[]" name="dias[]" value="Miercoles" type="checkbox">
        <label for="dias[]"> Miercoles </label>
        <br>

        <input id="dias[]" name="dias[]" value="Jueves" type="checkbox">
        <label for="dias[]"> Jueves </label>
        <br>

        <input id="dias[]" name="dias[]" value="Viernes" type="checkbox">
        <label for="dias[]"> Viernes </label>
        <br>


    </section>
        <h4>Hora</h4>
    <section>
        <input id = "78" name="horas[]" value="7-8" type="checkbox">
        <label for = "78">7-8</label>
        <br>
        <input id = "89" name="horas[]" value="8-9" type="checkbox">
        <label for = "89">8-9</label>
        <br>
        <input id = "910" name="horas[]" value="9-10" type="checkbox">
        <label for = "910">9-10</label>
        <br>
        <input id = "1011" name="horas[]" value="10-11" type="checkbox">
        <label for = "1011">10-11</label>
        <br>
        <input id = "1112" name="horas[]" value="11-12" type="checkbox">
        <label for = "1112">11-12</label>
        <br>
        <input id = "1213" name="horas[]" value="12-13" type="checkbox">
        <label for = "1213">12-13</label>
        <br>
        <input id = "1314" name="horas[]" value="13-14" type="checkbox">
        <label for = "1314">13-14</label>
        <br>
        <input id = "1415" name="horas[]" value="14-15" type="checkbox">
        <label for = "1415">14-15</label>
        <br>
        <input id = "1516" name="horas[]" value="15-16" type="checkbox">
        <label for = "1516">15-16</label>
        <br>
        <input id = "1617" name="horas[]" value="16-17" type="checkbox">
        <label for = "1617">16-17</label>
        <br>
        <input id = "1718" name="horas[]" value="17-18" type="checkbox">
        <label for = "1718">17-18</label>
        <br>
        <input id = "1819" name="horas[]" value="18-19" type="checkbox">
        <label for = "1819">18-19</label>

        <br>
        <br>
        <input type="submit" value="Enviar">

    </section>
</body>
</html>